# DawnBot
本地识别验证码,自动登入,并且保持keepalive会话.

### 安装依赖
在开始使用 DawnBot 之前，请确保安装了所有必要的依赖。

执行以下命令以安装依赖：

```
pip install -r requirements.txt
```
