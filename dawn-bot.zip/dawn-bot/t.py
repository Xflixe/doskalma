import time
from TempMail import TempMail

# Buat objek TempMail
tmp = TempMail()  # Atau tambahkan API key jika diperlukan: TempMail("tm.1234567890.randomcharactershere")

# Buat inbox baru
inbox = tmp.createInbox()

def print_emails(emails):
    print("Emails:")
    for email in emails:
        print("\tSender: " + email.sender)
        print("\tRecipient: " + email.recipient)
        print("\tSubject: " + email.subject)
        print("\tBody: " + email.body)
        print("\tHTML: " + str(email.html))  # mungkin None
        print("\tDate: " + str(email.date))  # Timestamp Unix dalam milidetik

# Tampilkan email awal
emails = tmp.getEmails(inbox)
print_emails(emails)

# Tunggu pesan baru
while True:
    try:
        # Periksa email baru
        new_emails = tmp.getEmails(inbox)
        
        # Jika ada email baru, tampilkan
        if new_emails:
            print("New Emails:")
            print_emails(new_emails)
        
        # Tunggu beberapa detik sebelum memeriksa lagi
        time.sleep(10)  # Tunggu 10 detik, sesuaikan sesuai kebutuhan

    except Exception as e:
        print("Terjadi kesalahan:", e)
        time.sleep(10)
