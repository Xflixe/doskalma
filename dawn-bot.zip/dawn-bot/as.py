import requests
import random
import time
import base64
import datetime
import numpy as np
from PIL import Image, ImageOps
from io import BytesIO
import ddddocr
from loguru import logger
from faker import Faker
import re

# Initialize Faker and OCR
fake = Faker()
ocr = ddddocr.DdddOcr(show_ad=False, det=False, ocr=False, import_onnx_path="dawn.onnx", charsets_path="charsets.json")

def process_image(image):
    gray_img = ImageOps.grayscale(image)
    img_array = np.array(gray_img)
    processed_img_array = np.ones_like(img_array) * 255
    black_threshold_low = 0
    black_threshold_high = 50
    mask = (img_array >= black_threshold_low) & (img_array <= black_threshold_high)
    processed_img_array[mask] = 0
    processed_img = Image.fromarray(processed_img_array)
    return processed_img

def get_temp_email_address():
    response = requests.get('https://api.mail.tm/domains')
    if response.status_code != 200:
        print(Fore.RED + Style.BRIGHT + "Gagal mendapatkan domain email.")
        print(Fore.RED + Style.BRIGHT + "Respon:", response.text)
        return None
    data = response.json()
    if not data or 'hydra:member' not in data or len(data['hydra:member']) == 0:
        print(Fore.RED + Style.BRIGHT + "Tidak ada domain email yang tersedia.")
        return None
    domain = data['hydra:member'][0]['domain']
    email_prefix = fake.user_name() + str(random.randint(1000, 9999))
    email_address = f"{email_prefix}@{domain}"
    return email_address

def create_temp_email(email_address):
    response = requests.post('https://api.mail.tm/accounts', json={
        'address': email_address,
        'password': 'password123'
    })
    if response.status_code != 201:
        print(Fore.RED + Style.BRIGHT + "Gagal membuat email sementara.")
        print(Fore.RED + Style.BRIGHT + "Respon:", response.text)
        return None, None, None
    data = response.json()
    return data.get('address'), 'password123', data.get('id')

def get_access_token(email, password):
    response = requests.post('https://api.mail.tm/token', json={
        'address': email,
        'password': password
    })
    if response.status_code != 200:
        print(Fore.RED + Style.BRIGHT + "Gagal mendapatkan token akses.")
        print(Fore.RED + Style.BRIGHT + "Respon:", response.text)
        return None
    return response.json().get('token')

def get_latest_email(token):
    headers = {'Authorization': f'Bearer {token}'}
    response = requests.get('https://api.mail.tm/messages', headers=headers, verify=False)  # Menonaktifkan verifikasi SSL
    if response.status_code != 200:
        print(Fore.RED + Style.BRIGHT + "Gagal mendapatkan email terbaru.")
        print(Fore.RED + Style.BRIGHT + "Respon:", response.text)
        return None, None
    messages = response.json().get('hydra:member', [])
    if messages:
        latest_email = messages[0]
        message_id = latest_email.get('id')
        # Get the full message details
        message_response = requests.get(f'https://api.mail.tm/messages/{message_id}', headers=headers, verify=False)  # Menonaktifkan verifikasi SSL
        if message_response.status_code == 200:
            message_data = message_response.json()
            subject = message_data.get('subject')
            text = message_data.get('text')
            # Extract verification URL using regex
            match = re.search(r'https://www\.aeropres\.in/chromeapi/dawn/v1/user/verifylink\?key=[\w-]+', text)
            verification_url = match.group(0) if match else None
            return subject, verification_url
    return None, None

def visit_verification_url(url):
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Sec-GPC': '1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not)A;Brand";v="99", "Brave";v="127", "Chromium";v="127"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"'
    }
    try:
        print(Fore.YELLOW + Style.BRIGHT + f"Mengunjungi URL: {url}")
        response = requests.get(url, headers=headers, verify=False)  # Menonaktifkan verifikasi SSL
        response.raise_for_status()  # Raises HTTPError for bad responses
        if response.status_code == 200:
            print(Fore.GREEN + Style.BRIGHT + "Berhasil mengunjungi URL verifikasi!")
        else:
            print(Fore.RED + Style.BRIGHT + f"Gagal mengunjungi URL verifikasi. Status Code: {response.status_code}")
            print(Fore.RED + Style.BRIGHT + "Respon:", response.text)
    except requests.RequestException as e:
        print(Fore.RED + Style.BRIGHT + "Terjadi kesalahan saat mengunjungi URL verifikasi.")
        print(Fore.RED + Style.BRIGHT + str(e))

def run(email, password, firstname, lastname, proxy=None):
    session = requests.session()
    session.verify = False
    try:
        if proxy is None:
            proxies = None
        else:
            proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        
        # Get puzzle ID
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle',
                               headers=headers, proxies=proxies).json()
        puzzle_id = response['puzzle_id']
        
        # Get puzzle image
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'pragma': 'no-cache',
            'priority': 'u=1, i',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        params = {'puzzle_id': puzzle_id}
        response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle-image', params=params,
                               headers=headers, proxies=proxies).json()
        base64_image = response['imgBase64']
        image_data = base64.b64decode(base64_image)
        image = Image.open(BytesIO(image_data))
        new_image = process_image(image)
        result = ocr.classification(new_image)
        
        # Send registration data
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'content-type': 'application/json',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        json_data = {
            "firstname": firstname,
            "lastname": lastname,
            "email": email,
            "mobile": "",
            "password": password,
            "country": "+91",
            "referralCode": "",
            "puzzle_id": puzzle_id,
            "ans": result
        }
        response = session.post(
            'https://www.aeropres.in/chromeapi/dawn/v1/puzzle/validate-register',
            headers=headers,
            json=json_data,
            proxies=proxies
        ).json()
        logger.debug(response)
    except Exception as e:
        logger.error(e)

if __name__ == '__main__':
    # proxy ip:port:user:pwd
    email = get_temp_email_address()
    if email:
        email, password, _ = create_temp_email(email)
        if email:
            print(f"Email sementara berhasil dibuat: {email}")
            run(email, password, 'juwiring', 'fatkhur', proxy=None)
            while True:
                token = get_access_token(email, password)
                if token:
                    subject, verification_url = get_latest_email(token)
                    if verification_url:
                        print(f"Email baru diterima!")
                        print(f"URL Verifikasi: {verification_url}")
                        visit_verification_url(verification_url)
                        break
                time.sleep(10)  # Delay before checking again
