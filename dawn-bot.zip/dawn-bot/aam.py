import random
import time

from PIL import Image
import datetime
import base64
import requests
from io import BytesIO
import numpy as np
from PIL import ImageOps
import ddddocr
from loguru import logger
from faker import Faker

ocr = ddddocr.DdddOcr(show_ad=False, det=False, ocr=False, import_onnx_path="dawn.onnx", charsets_path="charsets.json")
fake = Faker()  # Initialize Faker

def process_image(image):
    gray_img = ImageOps.grayscale(image)
    img_array = np.array(gray_img)
    processed_img_array = np.ones_like(img_array) * 255
    black_threshold_low = 0
    black_threshold_high = 50
    mask = (img_array >= black_threshold_low) & (img_array <= black_threshold_high)
    processed_img_array[mask] = 0
    processed_img = Image.fromarray(processed_img_array)
    return processed_img

def run(email, password):
    session = requests.session()
    session.verify = False
    try:
        proxies = None
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle',
                               headers=headers, proxies=proxies).json()
        puzzle_id = response['puzzle_id']
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'pragma': 'no-cache',
            'priority': 'u=1, i',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        params = {'puzzle_id': puzzle_id}
        response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle-image', params=params,
                               headers=headers, proxies=proxies).json()
        base64_image = response['imgBase64']
        image_data = base64.b64decode(base64_image)
        image = Image.open(BytesIO(image_data))
        new_image = process_image(image)
        result = ocr.classification(new_image)
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'content-type': 'application/json',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        current_time = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace(
            "+00:00", "Z")
        json_data = {
            "firstname": fake.first_name(),  # Generate a random first name
            "lastname": fake.last_name(),    # Generate a random last name
            "email": email,
            "mobile": "",
            "password": password,
            "country": "+91",
            "referralCode": "",
            "puzzle_id": puzzle_id,
            "ans": result
        }
        response = session.post('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/validate-register', headers=headers,
                                json=json_data, proxies=proxies).json()
        logger.debug(response)
    except Exception as e:
        logger.error(e)

if __name__ == '__main__':
    email = input('Enter your email: ')
    password = input('Enter your password: ')
    run(email, password)
