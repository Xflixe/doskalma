import random
import time
from PIL import Image, ImageOps
import datetime
import base64
import requests
from io import BytesIO
import numpy as np
import ddddocr
from loguru import logger

ocr = ddddocr.DdddOcr(show_ad=False, det=False, ocr=False, import_onnx_path="dawn.onnx", charsets_path="charsets.json")


def process_image(image, black_threshold_low=0, black_threshold_high=50):
    gray_img = ImageOps.grayscale(image)
    img_array = np.array(gray_img)
    processed_img_array = np.ones_like(img_array) * 255
    mask = (img_array >= black_threshold_low) & (img_array <= black_threshold_high)
    processed_img_array[mask] = 0
    return Image.fromarray(processed_img_array)


def get_puzzle(session, headers, proxies):
    response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle', headers=headers, proxies=proxies).json()
    return response['puzzle_id']


def get_puzzle_image(session, headers, proxies, puzzle_id):
    params = {'puzzle_id': puzzle_id}
    response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle-image', params=params,
                           headers=headers, proxies=proxies).json()
    return response['imgBase64']


def process_ocr_image(base64_image):
    image_data = base64.b64decode(base64_image)
    image = Image.open(BytesIO(image_data))
    processed_img = process_image(image)
    return ocr.classification(processed_img)


def login(session, headers, proxies, email, password, puzzle_id, result):
    current_time = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace("+00:00", "Z")
    json_data = {
        'username': email,
        'password': password,
        'logindata': {'_v': '1.0.7', 'datetime': current_time},
        'puzzle_id': puzzle_id,
        'ans': result
    }
    response = session.post('https://www.aeropres.in/chromeapi/dawn/v1/user/login/v2', headers=headers,
                            json=json_data, proxies=proxies).json()
    return response


def keep_alive(session, headers, proxies, email, token):
    json_data = {
        'username': email,
        'extensionid': 'fpdkjdnhkakefebpekbdhillbhonfjjp',
        'numberoftabs': 0,
        '_v': '1.0.7'
    }
    response = session.post('https://www.aeropres.in/chromeapi/dawn/v1/userreward/keepalive',
                            headers=headers, json=json_data, proxies=proxies, timeout=30).json()
    return response


def initialize_session(proxy=None):
    session = requests.Session()
    session.verify = False
    proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"} if proxy else None
    headers = {
        'accept': '*/*',
        'accept-language': 'zh-CN,zh;q=0.9',
        'cache-control': 'no-cache',
        'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    }
    return session, headers, proxies


def main(email, password, proxy=None):
    session, headers, proxies = initialize_session(proxy)
    
    try:
        puzzle_id = get_puzzle(session, headers, proxies)
        base64_image = get_puzzle_image(session, headers, proxies, puzzle_id)
        result = process_ocr_image(base64_image)

        headers['content-type'] = 'application/json'
        login_response = login(session, headers, proxies, email, password, puzzle_id, result)
        logger.debug(login_response)

        if login_response['status']:
            logger.success(login_response['message'])
            token = login_response['data']['token']
            while True:
                try:
                    headers['authorization'] = f'Bearer {token}'
                    keep_alive_response = keep_alive(session, headers, proxies, email, token)
                    logger.debug(keep_alive_response)
                    time.sleep(random.randint(100, 150))
                except Exception as e:
                    logger.error(f"Error during keep-alive: {e}")
        else:
            logger.warning(login_response['message'])
    except Exception as e:
        logger.error(f"An error occurred: {e}")


if __name__ == '__main__':
    # Call the main function with appropriate parameters
    main('fatkhurdealova@gmail.com', 'Cepiring@123', proxy=None)
