import os
import requests
import asyncio
import random
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

TEMPMAIL_API_KEY = os.getenv("TEMPMAIL_API_KEY")
NAMESPACE = os.getenv("NAMESPACE")

EMAIL_DOMAIN = "@inbox.testmail.app"

def generate_random_email():
    random_name = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz1234567890', k=6))
    return f"{NAMESPACE}.{random_name}{EMAIL_DOMAIN}"

def generate_custom_email(keyword):
    return f"{NAMESPACE}.{keyword}{EMAIL_DOMAIN}"

async def get_inbox(email):
    url = f"https://api.testmail.app/api/json?apikey={TEMPMAIL_API_KEY}&namespace={NAMESPACE}&pretty=true"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            emails = data.get("emails", [])
            return emails
    except Exception as e:
        print(f"Error fetching inbox: {e}")
    return []

async def monitor_inbox(email):
    print(f"Monitoring inbox for {email}...")
    while True:
        emails = await get_inbox(email)
        if emails:
            print(f"📨 New email(s) received!")
            for email in emails:
                from_email = email.get("from", "Unknown")
                subject = email.get("subject", "No Subject")
                body = email.get("text", "No Body")
                print(f"**From**: {from_email}\n**Subject**: {subject}\n**Message**:\n{body}\n")
        else:
            print("📬 No new emails yet.")
        await asyncio.sleep(300)  # Check every 5 minutes

def main():
    email = generate_random_email()
    print(f"Generated email: {email}")
    asyncio.run(monitor_inbox(email))

if __name__ == "__main__":
    main()
