from .core import TempMail
