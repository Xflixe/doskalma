import requests
import time
import random
from faker import Faker
import re
from colorama import Fore, Style, init
from PIL import Image
import datetime
import base64
from io import BytesIO
import numpy as np
from PIL import ImageOps
import ddddocr
from loguru import logger
import asyncio

init(autoreset=True)
fake = Faker()

ocr = ddddocr.DdddOcr(show_ad=False, det=False, ocr=False, import_onnx_path="dawn.onnx", charsets_path="charsets.json")

TEMPMAIL_API_KEY = "b3bdf279-7e24-4ca1-9a04-5621819bad0c"
NAMESPACE = "d8gjg"
EMAIL_DOMAIN = "@inbox.testmail.app"

def process_image(image):
    gray_img = ImageOps.grayscale(image)
    img_array = np.array(gray_img)
    processed_img_array = np.ones_like(img_array) * 255
    black_threshold_low = 0
    black_threshold_high = 50
    mask = (img_array >= black_threshold_low) & (img_array <= black_threshold_high)
    processed_img_array[mask] = 0
    processed_img = Image.fromarray(processed_img_array)
    return processed_img

def generate_random_email():
    random_name = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz1234567890', k=6))
    return f"{NAMESPACE}.{random_name}{EMAIL_DOMAIN}"

async def get_inbox(email):
    url = f"https://api.testmail.app/api/json?apikey={TEMPMAIL_API_KEY}&namespace={NAMESPACE}&pretty=true"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            emails = data.get("emails", [])
            return emails
    except Exception as e:
        print(f"Error fetching inbox: {e}")
    return []

async def extract_verification_link(text):
    url_pattern = re.compile(r'https://[^\s]+')
    urls = url_pattern.findall(text)
    for url in urls:
        if 'verifylink' in url:
            return url
    return "No verification link found."

async def monitor_inbox(email):
    print(f"Monitoring inbox for {email}...")
    while True:
        emails = await get_inbox(email)
        if emails:
            latest_email = emails[0]
            body = latest_email.get("text", "")
            verification_link = await extract_verification_link(body)
            if verification_link:
                print(f"📨 Verification link received:\n{verification_link}")
                time.sleep(5)
                visit_verification_url(verification_link)  # Mengunjungi URL verifikasi
                break
            else:
                print("📬 No verification link found.")
        else:
            print("📬 No new emails yet.")
        await asyncio.sleep(300)

def visit_verification_url(url):
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Sec-GPC': '1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Not)A;Brand";v="99", "Brave";v="127", "Chromium";v="127"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"'
    }
    try:
        print(Fore.YELLOW + Style.BRIGHT + f"Mengunjungi URL: {url}")
        response = requests.get(url, headers=headers, verify=False)  # Menonaktifkan verifikasi SSL
        response.raise_for_status()  # Raises HTTPError for bad responses
        if response.status_code == 200:
            print(Fore.GREEN + Style.BRIGHT + "Berhasil mengunjungi URL verifikasi!")
        else:
            print(Fore.RED + Style.BRIGHT + f"Gagal mengunjungi URL verifikasi. Status Code: {response.status_code}")
            print(Fore.RED + Style.BRIGHT + "Respon:", response.text)
    except requests.RequestException as e:
        print(Fore.RED + Style.BRIGHT + "Terjadi kesalahan saat mengunjungi URL verifikasi.")
        print(Fore.RED + Style.BRIGHT + str(e))

def main(proxy=None):
    email = generate_random_email()
    print(f"Generated email: {email}")

    session = requests.session()
    session.verify = False
    try:
        if proxy is None:
            proxies = None
        else:
            proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle',
                               headers=headers, proxies=proxies).json()
        puzzle_id = response['puzzle_id']
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'priority': 'u=1, i',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        }
        params = {'puzzle_id': puzzle_id, }
        response = session.get('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/get-puzzle-image', params=params,
                               headers=headers, proxies=proxies).json()
        base64_image = response['imgBase64']
        image_data = base64.b64decode(base64_image)
        image = Image.open(BytesIO(image_data))
        new_image = process_image(image)
        result = ocr.classification(new_image)
        headers = {
            'accept': '*/*',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'content-type': 'application/json',
            'origin': 'chrome-extension://fpdkjdnhkakefebpekbdhillbhonfjjp',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',        }
        firstname = fake.first_name()
        lastname = fake.last_name()
        current_time = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace(
            "+00:00", "Z")
        json_data = {
            "firstname": firstname,
            "lastname": lastname,
            "email": email,
            "mobile": "",
            "password": "Cepiring@123",
            "country": "+91",
            "referralCode": "",
            "puzzle_id": puzzle_id,
            "ans": result
        }
        logger.debug(f"Request data: {json_data}")
        response = session.post('https://www.aeropres.in/chromeapi/dawn/v1/puzzle/validate-register', headers=headers,
                                json=json_data, proxies=proxies).json()
        logger.debug(response)

    except Exception as e:
        logger.error(e)
    asyncio.run(monitor_inbox(email))
    

if __name__ == '__main__':
    main(proxy=None)
