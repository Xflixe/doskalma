from TempMail import TempMail
import time

# Inisialisasi objek TempMail
tm = TempMail()

# Generate email sementara
email = tm.generate_email()
print(f"Generated email: {email}")

# Tunggu beberapa detik untuk memungkinkan pesan masuk
print("Menunggu pesan...")
time.sleep(60)  # Tunggu 60 detik

# Periksa inbox untuk pesan baru
inbox = tm.check_inbox()
if inbox:
    for message in inbox:
        print(f"Pesan baru: {message}")
else:
    print("Tidak ada pesan baru.")
